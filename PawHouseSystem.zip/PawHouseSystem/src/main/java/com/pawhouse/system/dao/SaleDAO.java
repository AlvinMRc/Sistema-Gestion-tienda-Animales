
package com.pawhouse.system.dao;

import com.pawhouse.system.config.DatabaseConnection;
import com.pawhouse.system.models.Sale;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SaleDAO {

    // ================= REGISTRAR =================
    public boolean registrarSale(Sale s) {

        String sql = "INSERT INTO Sale "
                + "(SaleID, SaleDate, EmployeeID, CustomerID, SalesTax) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, s.getSaleID());
            pst.setString(2, s.getSaleDate());
            pst.setInt(3, s.getEmployeeID());
            pst.setInt(4, s.getCustomerID());
            pst.setDouble(5, s.getSalesTax());

            return pst.executeUpdate() > 0;

        } catch (SQLException ex) {

            System.err.println(
                    "Error al registrar venta: "
                    + ex.getMessage()
            );

            return false;
        }
    }

    // ================= BUSCAR =================
    public List<Sale> buscarSales(String filtro) {

        List<Sale> lista = new ArrayList<>();

        String sql = "SELECT * FROM Sale "
                + "WHERE SaleDate LIKE ? "
                + "OR CustomerID LIKE ?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, "%" + filtro + "%");
            pst.setString(2, "%" + filtro + "%");

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {

                Sale s = new Sale();

                s.setSaleID(
                        rs.getInt("SaleID")
                );

                s.setSaleDate(
                        rs.getString("SaleDate")
                );

                s.setEmployeeID(
                        rs.getInt("EmployeeID")
                );

                s.setCustomerID(
                        rs.getInt("CustomerID")
                );

                s.setSalesTax(
                        rs.getDouble("SalesTax")
                );

                lista.add(s);
            }

        } catch (SQLException ex) {

            System.err.println(
                    "Error al buscar ventas: "
                    + ex.getMessage()
            );
        }

        return lista;
    }

    // ================= ACTUALIZAR =================
    public boolean actualizarSale(Sale s) {

        String sql = "UPDATE Sale SET "
                + "SaleDate=?, "
                + "EmployeeID=?, "
                + "CustomerID=?, "
                + "SalesTax=? "
                + "WHERE SaleID=?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, s.getSaleDate());
            pst.setInt(2, s.getEmployeeID());
            pst.setInt(3, s.getCustomerID());
            pst.setDouble(4, s.getSalesTax());
            pst.setInt(5, s.getSaleID());

            return pst.executeUpdate() > 0;

        } catch (SQLException ex) {

            System.err.println(
                    "Error al actualizar venta: "
                    + ex.getMessage()
            );

            return false;
        }
    }

    // ================= ELIMINAR =================
    public boolean eliminarSale(int saleID) {

        String sql = "DELETE FROM Sale "
                + "WHERE SaleID=?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, saleID);

            return pst.executeUpdate() > 0;

        } catch (SQLException ex) {

            System.err.println(
                    "Error al eliminar venta: "
                    + ex.getMessage()
            );

            return false;
        }
    }
}