
package com.pawhouse.system.models;

public class Sale {

    private int saleID;
    private String saleDate;
    private int employeeID;
    private int customerID;
    private double salesTax;

    // Constructor vacío
    public Sale() {}

    // Constructor con parámetros
    public Sale(String saleDate,
                int employeeID,
                int customerID,
                double salesTax) {

        this.saleDate = saleDate;
        this.employeeID = employeeID;
        this.customerID = customerID;
        this.salesTax = salesTax;
    }

    // Getters y Setters

    public int getSaleID() {
        return saleID;
    }

    public void setSaleID(int saleID) {
        this.saleID = saleID;
    }

    public String getSaleDate() {
        return saleDate;
    }

    public void setSaleDate(String saleDate) {
        this.saleDate = saleDate;
    }

    public int getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(int employeeID) {
        this.employeeID = employeeID;
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public double getSalesTax() {
        return salesTax;
    }

    public void setSalesTax(double salesTax) {
        this.salesTax = salesTax;
    }
}