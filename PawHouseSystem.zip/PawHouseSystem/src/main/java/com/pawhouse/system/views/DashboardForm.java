package com.pawhouse.system.views;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class DashboardForm extends JFrame {

    private CardLayout cardLayout;
    private JPanel panelContenedor;
    private final String rolUsuario;

    // Controla el tema actual (inicia en oscuro)
    private static boolean modoOscuro = true;

    // ================= HELPER: detecta si el rol es administrador =================
    public static boolean esRolAdmin(String rol) {
        if (rol == null) return false;
        String r = rol.trim().toUpperCase();
        return r.equals("ADMIN") || r.equals("ADMINISTRADOR") || r.startsWith("ADMIN");
    }

    // ================= FLAT LAF SETUP =================
    public static void configurarLookAndFeel() {
        try {
            FlatDarkLaf.setup();
            aplicarEstilosGlobales();
        } catch (Exception e) {
            System.err.println("FlatLaf no disponible, usando L&F por defecto.");
        }
    }

    /** Aplica los UIManager overrides comunes a ambos temas */
    private static void aplicarEstilosGlobales() {
        UIManager.put("Button.arc",           16);
        UIManager.put("Component.arc",        12);
        UIManager.put("TextComponent.arc",    10);
        UIManager.put("CheckBox.arc",          6);
        UIManager.put("ScrollBar.thumbArc",  999);
        UIManager.put("ScrollBar.width",       8);
        UIManager.put("Component.focusColor", new Color(244, 162, 97));
        UIManager.put("TabbedPane.selectedBackground", new Color(45, 45, 45));
        UIManager.put("Button.borderWidth",    0);
    }

    public DashboardForm(String rolUsuario) {
        this.rolUsuario = rolUsuario;

        setTitle("Paw House System  |  Usuario: " + rolUsuario.toUpperCase());
        setSize(1250, 780);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ================= SIDEBAR =================
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(24, 24, 24));
        sidebar.setPreferredSize(new Dimension(220, 0));

        JLabel lblLogo = new JLabel("PAW HOUSE", SwingConstants.CENTER);
        lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblLogo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblLogo.setForeground(new Color(244, 162, 97));
        lblLogo.setBorder(BorderFactory.createEmptyBorder(25, 0, 10, 0));
        sidebar.add(lblLogo);

        boolean esAdmin = esRolAdmin(rolUsuario);
        String textoRol = esAdmin ? "● Administrador" : "● Empleado";
        Color  colorRol = esAdmin ? new Color(46, 204, 113) : new Color(149, 165, 166);

        JLabel lblRol = new JLabel(textoRol, SwingConstants.CENTER);
        lblRol.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblRol.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblRol.setForeground(colorRol);
        lblRol.setBorder(BorderFactory.createEmptyBorder(0, 0, 25, 0));
        sidebar.add(lblRol);

        sidebar.add(crearBotonMenu("  Inicio",          "INICIO"));
        sidebar.add(crearBotonMenu("  Clientes",        "CLIENTES"));
        sidebar.add(crearBotonMenu("  Animales",        "ANIMAL"));
        sidebar.add(crearBotonMenu("  Animal Orders",   "ANIMALORDER"));
        sidebar.add(crearBotonMenu("  Order Items",     "ANIMALORDERITEM"));
        sidebar.add(crearBotonMenu("  Empleados",       "EMPLOYEE"));
        sidebar.add(crearBotonMenu("  Ventas",          "SALE"));
        sidebar.add(crearBotonMenu("  Sale Animals",    "SALEANIMAL"));
        sidebar.add(crearBotonMenu("  Ayuda",           "AYUDA"));

        sidebar.add(Box.createVerticalGlue());

        // ================= BOTÓN MODO OSCURO/CLARO =================
        JButton btnTema = new JButton("  Modo Claro");
        btnTema.setMaximumSize(new Dimension(220, 44));
        btnTema.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnTema.setBackground(new Color(50, 50, 80));
        btnTema.setForeground(Color.WHITE);
        btnTema.setFocusPainted(false);
        btnTema.setBorderPainted(false);
        btnTema.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btnTema.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnTema.setHorizontalAlignment(SwingConstants.LEFT);
        btnTema.setMargin(new Insets(0, 18, 0, 0));
        btnTema.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btnTema.setBackground(new Color(70, 70, 110)); }
            @Override public void mouseExited(MouseEvent e)  { btnTema.setBackground(new Color(50, 50, 80)); }
        });
        btnTema.addActionListener(e -> alternarTema(btnTema));
        sidebar.add(btnTema);
        sidebar.add(Box.createRigidArea(new Dimension(0, 6)));

        sidebar.add(crearBotonMenu("  Cerrar Sesión",   "LOGOUT"));
        sidebar.add(Box.createRigidArea(new Dimension(0, 20)));

        add(sidebar, BorderLayout.WEST);

        // ================= CONTENEDOR CENTRAL =================
        cardLayout      = new CardLayout();
        panelContenedor = new JPanel(cardLayout);
        panelContenedor.setBackground(new Color(35, 35, 35));

        panelContenedor.add(new PanelInicio(),                    "INICIO");
        panelContenedor.add(new PanelAnimal(rolUsuario),          "ANIMAL");
        panelContenedor.add(new PanelClientes(rolUsuario),        "CLIENTES");
        panelContenedor.add(new PanelAnimalOrder(rolUsuario),     "ANIMALORDER");
        panelContenedor.add(new PanelAnimalOrderItem(rolUsuario), "ANIMALORDERITEM");
        panelContenedor.add(new PanelEmployee(rolUsuario),        "EMPLOYEE");
        panelContenedor.add(new PanelSale(rolUsuario),            "SALE");
        panelContenedor.add(new PanelSaleAnimal(rolUsuario),      "SALEANIMAL");
        panelContenedor.add(new PanelAyuda(),                     "AYUDA");

        cardLayout.show(panelContenedor, "INICIO");
        add(panelContenedor, BorderLayout.CENTER);
    }

    // ================= ALTERNAR TEMA =================
    private void alternarTema(JButton btnTema) {
        try {
            if (modoOscuro) {
                // Cambiar a claro
                FlatLightLaf.setup();
                modoOscuro = false;
                btnTema.setText(" Modo Oscuro");
            } else {
                // Cambiar a oscuro
                FlatDarkLaf.setup();
                modoOscuro = true;
                btnTema.setText(" Modo Claro");
            }
            aplicarEstilosGlobales();

            // Actualizar todas las ventanas abiertas
            for (Window w : Window.getWindows()) {
                SwingUtilities.updateComponentTreeUI(w);
                if (w instanceof JFrame) {
                    ((JFrame) w).pack();
                    // Restaurar tamaño fijo del dashboard
                    if (w instanceof DashboardForm) {
                        w.setSize(1250, 780);
                        w.setLocationRelativeTo(null);
                    }
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo cambiar el tema: " + ex.getMessage(),
                    "Error de tema", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JButton crearBotonMenu(String texto, String comando) {
        JButton btn = new JButton(texto);
        btn.setMaximumSize(new Dimension(220, 48));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setBackground(new Color(24, 24, 24));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setMargin(new Insets(0, 18, 0, 0));

        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(new Color(45, 45, 45)); }
            @Override public void mouseExited(MouseEvent e)  { btn.setBackground(new Color(24, 24, 24)); }
        });

        btn.addActionListener(e -> {
            if (comando.equals("LOGOUT")) {
                int confirm = JOptionPane.showConfirmDialog(
                        this, "¿Seguro que desea cerrar sesión?",
                        "Salir", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    new LoginForm().setVisible(true);
                    dispose();
                }
            } else {
                cardLayout.show(panelContenedor, comando);
            }
        });
        return btn;
    }
}