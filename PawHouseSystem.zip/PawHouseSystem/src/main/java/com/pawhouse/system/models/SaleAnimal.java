
package com.pawhouse.system.models;
public class SaleAnimal {

    private int saleID;
    private int animalID;
    private double salePrice;

    // Constructor vacío
    public SaleAnimal() {}

    // Constructor con parámetros
    public SaleAnimal(int saleID,
                      int animalID,
                      double salePrice) {

        this.saleID = saleID;
        this.animalID = animalID;
        this.salePrice = salePrice;
    }

    // Getters y Setters

    public int getSaleID() {
        return saleID;
    }

    public void setSaleID(int saleID) {
        this.saleID = saleID;
    }

    public int getAnimalID() {
        return animalID;
    }

    public void setAnimalID(int animalID) {
        this.animalID = animalID;
    }

    public double getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(double salePrice) {
        this.salePrice = salePrice;
    }
}