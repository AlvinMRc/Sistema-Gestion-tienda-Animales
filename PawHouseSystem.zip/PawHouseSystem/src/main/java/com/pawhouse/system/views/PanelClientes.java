package com.pawhouse.system.views;

import com.pawhouse.system.dao.ClienteDAO;
import com.pawhouse.system.models.Cliente;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelClientes extends JPanel {

    private JTextField txtCedula, txtNombre, txtTelefono, txtBuscar;
    private JCheckBox chkEstado;
    private JButton btnRegistrar, btnActualizar, btnDesactivar, btnEliminar;
    private JTable table;
    private DefaultTableModel modeloTabla;
    private ClienteDAO clienteDAO;
    private int idSeleccionado = -1;
    private final boolean esAdmin;

    public PanelClientes(String rol) {
        this.esAdmin = DashboardForm.esRolAdmin(rol);
        clienteDAO = new ClienteDAO();
        construirUI();
        listarClientes();
    }

    public PanelClientes() { this("ADMIN"); }

    private void construirUI() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(35, 35, 35));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // --- BUSCADOR ---
        JPanel panelBuscar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBuscar.setBackground(new Color(35, 35, 35));
        panelBuscar.add(crearLabel("Buscar:"));
        txtBuscar = new JTextField(20);
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override public void keyReleased(java.awt.event.KeyEvent evt) { listarClientes(); }
        });
        panelBuscar.add(txtBuscar);
        add(panelBuscar, BorderLayout.NORTH);

        // --- TABLA Y FORMULARIO ---
        JPanel panelCentro = new JPanel(new GridLayout(1, 2, 15, 0));
        panelCentro.setBackground(new Color(35, 35, 35));

        modeloTabla = new DefaultTableModel(new Object[]{"ID","Cédula","Nombre","Teléfono","Estado"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(modeloTabla);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(25);
        table.setSelectionBackground(new Color(244, 162, 97, 80));
        table.getSelectionModel().addListSelectionListener(e -> llenarFormularioDesdeTabla());
        panelCentro.add(new JScrollPane(table));

        JPanel formPanel = new JPanel(new GridLayout(9, 2, 5, 8));
        formPanel.setBackground(new Color(45, 45, 45));
        formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(70, 70, 70)),
                "Datos del Cliente", 0, 0,
                new Font("Segoe UI", Font.BOLD, 14), Color.WHITE));

        formPanel.add(crearLabel("Cédula/RNC:")); txtCedula   = new JTextField(); formPanel.add(txtCedula);
        formPanel.add(crearLabel("Nombre:"));     txtNombre   = new JTextField(); formPanel.add(txtNombre);
        formPanel.add(crearLabel("Teléfono:"));   txtTelefono = new JTextField(); formPanel.add(txtTelefono);
        formPanel.add(crearLabel("Activo:"));
        chkEstado = new JCheckBox(); chkEstado.setSelected(true);
        chkEstado.setBackground(new Color(45, 45, 45)); formPanel.add(chkEstado);

        formPanel.add(new JLabel("")); formPanel.add(new JLabel(""));
        formPanel.add(new JLabel("")); formPanel.add(new JLabel(""));

        btnRegistrar  = crearBoton("Registrar",  new Color(46, 204, 113),  e -> registrar());
        btnActualizar = crearBoton("Actualizar",  new Color(244, 162, 97), e -> actualizar());
        btnDesactivar = crearBoton("Desactivar",  new Color(241, 196, 15), e -> cambiarEstado(false));
        btnEliminar   = crearBoton("Eliminar",    new Color(231, 76, 60),  e -> eliminar());

        formPanel.add(btnRegistrar);
        formPanel.add(btnActualizar);
        formPanel.add(btnDesactivar);
        formPanel.add(btnEliminar);

        if (!esAdmin) {
            btnRegistrar.setEnabled(false);
            btnActualizar.setEnabled(false);
            btnEliminar.setEnabled(false);
            // Desactivar SÍ está disponible para usuarios normales (es lectura casi)
            btnDesactivar.setEnabled(false);
            String tip = "Solo disponible para administradores";
            btnRegistrar.setToolTipText(tip);
            btnActualizar.setToolTipText(tip);
            btnEliminar.setToolTipText(tip);
            btnDesactivar.setToolTipText(tip);
        }

        panelCentro.add(formPanel);
        add(panelCentro, BorderLayout.CENTER);
    }

    private void registrar() {
        try {
            Cliente c = new Cliente(txtCedula.getText(), txtNombre.getText(), txtTelefono.getText(), chkEstado.isSelected());
            if (clienteDAO.registrarCliente(c)) { listarClientes(); limpiarCampos(); }
            else JOptionPane.showMessageDialog(this, "No se pudo registrar el cliente.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizar() {
        if (idSeleccionado <= 0) return;
        try {
            Cliente c = new Cliente(txtCedula.getText(), txtNombre.getText(), txtTelefono.getText(), chkEstado.isSelected());
            c.setId(idSeleccionado);
            if (clienteDAO.actualizarCliente(c)) { listarClientes(); limpiarCampos(); }
            else JOptionPane.showMessageDialog(this, "No se pudo actualizar el cliente.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cambiarEstado(boolean estado) {
        if (idSeleccionado <= 0) return;
        clienteDAO.cambiarEstadoCliente(idSeleccionado, estado);
        listarClientes(); limpiarCampos();
    }

    private void eliminar() {
        if (idSeleccionado <= 0) return;
        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Seguro que desea ELIMINAR este cliente permanentemente?\n" +
                "Si tiene ventas asociadas no se podrá eliminar.",
                "Advertencia", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (clienteDAO.eliminarCliente(idSeleccionado)) {
                listarClientes(); limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this,
                        "No se puede eliminar este cliente.\n" +
                        "Tiene ventas registradas a su nombre.\n\n" +
                        "Elimine primero las ventas relacionadas\n" +
                        "o use el botón 'Desactivar' en su lugar.",
                        "Error de integridad referencial",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void listarClientes() {
        modeloTabla.setRowCount(0);
        List<Cliente> lista = clienteDAO.buscarClientes(txtBuscar.getText());
        for (Cliente c : lista) {
            modeloTabla.addRow(new Object[]{c.getId(), c.getCedula(), c.getNombre(), c.getTelefono(), c.isEstado() ? "Activo" : "Inactivo"});
        }
    }

    private void llenarFormularioDesdeTabla() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            idSeleccionado = (int) modeloTabla.getValueAt(row, 0);
            txtCedula.setText((String) modeloTabla.getValueAt(row, 1));
            txtNombre.setText((String) modeloTabla.getValueAt(row, 2));
            txtTelefono.setText((String) modeloTabla.getValueAt(row, 3));
            chkEstado.setSelected("Activo".equals(modeloTabla.getValueAt(row, 4)));
        }
    }

    private void limpiarCampos() {
        idSeleccionado = -1;
        txtCedula.setText(""); txtNombre.setText("");
        txtTelefono.setText(""); chkEstado.setSelected(true);
    }

    private JLabel crearLabel(String text) {
        JLabel lbl = new JLabel(text); lbl.setForeground(Color.WHITE); return lbl;
    }

    private JButton crearBoton(String text, Color bg, java.awt.event.ActionListener action) {
        JButton btn = new JButton(text);
        btn.setBackground(bg); btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false); btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setMargin(new Insets(5, 15, 5, 15));
        btn.putClientProperty("FlatLaf.style", String.format(
                "background: #%02x%02x%02x; foreground: #ffffff; font: bold 12 \'Segoe UI\'; arc: 16",
                bg.getRed(), bg.getGreen(), bg.getBlue()));
        btn.addActionListener(action);
        return btn;
    }
}