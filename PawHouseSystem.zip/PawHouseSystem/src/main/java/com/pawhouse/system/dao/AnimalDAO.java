
package com.pawhouse.system.dao;

import com.pawhouse.system.config.DatabaseConnection;
import com.pawhouse.system.models.Animal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AnimalDAO {

    // Registrar Animal
    public boolean registrarAnimal(Animal a) {
        String sql = "INSERT INTO Animal (AnimalID, Name, Category, Breed, DateBorn, Gender, Registered, Color, ListPrice) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, a.getAnimalID());
            pst.setString(2, a.getName());
            pst.setString(3, a.getCategory());
            pst.setString(4, a.getBreed());
            pst.setString(5, a.getDateBorn());
            pst.setString(6, a.getGender());
            pst.setString(7, a.getRegistered());
            pst.setString(8, a.getColor());
            pst.setDouble(9, a.getListPrice());

            return pst.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al registrar animal: " + e.getMessage());
            return false;
        }
    }

    // Buscar Animales
    public List<Animal> buscarAnimales(String filtro) {

        List<Animal> lista = new ArrayList<>();

        String sql = "SELECT * FROM Animal WHERE Name LIKE ? OR Category LIKE ?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, "%" + filtro + "%");
            pst.setString(2, "%" + filtro + "%");

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {

                Animal a = new Animal();

                a.setAnimalID(rs.getInt("AnimalID"));
                a.setName(rs.getString("Name"));
                a.setCategory(rs.getString("Category"));
                a.setBreed(rs.getString("Breed"));
                a.setDateBorn(rs.getString("DateBorn"));
                a.setGender(rs.getString("Gender"));
                a.setRegistered(rs.getString("Registered"));
                a.setColor(rs.getString("Color"));
                a.setListPrice(rs.getDouble("ListPrice"));

                lista.add(a);
            }

        } catch (SQLException e) {
            System.err.println("Error al buscar animales: " + e.getMessage());
        }

        return lista;
    }

    // Actualizar Animal
    public boolean actualizarAnimal(Animal a) {

        String sql = "UPDATE Animal SET Name=?, Category=?, Breed=?, DateBorn=?, Gender=?, Registered=?, Color=?, ListPrice=? WHERE AnimalID=?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, a.getName());
            pst.setString(2, a.getCategory());
            pst.setString(3, a.getBreed());
            pst.setString(4, a.getDateBorn());
            pst.setString(5, a.getGender());
            pst.setString(6, a.getRegistered());
            pst.setString(7, a.getColor());
            pst.setDouble(8, a.getListPrice());
            pst.setInt(9, a.getAnimalID());

            return pst.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar animal: " + e.getMessage());
            return false;
        }
    }

    // Eliminar Animal
    public boolean eliminarAnimal(int animalID) {

        String sql = "DELETE FROM Animal WHERE AnimalID=?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, animalID);

            return pst.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar animal: " + e.getMessage());
            return false;
        }
    }
}