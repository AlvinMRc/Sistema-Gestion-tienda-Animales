/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pawhouse.system.dao;

import com.pawhouse.system.config.DatabaseConnection;
import com.pawhouse.system.models.AnimalOrderItem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AnimalOrderItemDAO {

    // ================= REGISTRAR =================
    public boolean registrarItem(AnimalOrderItem item) {

        String sql = "INSERT INTO AnimalOrderItem "
                + "(OrderID, AnimalID, Cost) "
                + "VALUES (?, ?, ?)";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, item.getOrderID());
            pst.setInt(2, item.getAnimalID());
            pst.setDouble(3, item.getCost());

            return pst.executeUpdate() > 0;

        } catch (SQLException e) {

            System.err.println(
                    "Error al registrar item: "
                    + e.getMessage()
            );

            return false;
        }
    }

    // ================= BUSCAR =================
    public List<AnimalOrderItem> buscarItems(String filtro) {

        List<AnimalOrderItem> lista = new ArrayList<>();

        String sql = "SELECT * FROM AnimalOrderItem "
                + "WHERE OrderID LIKE ? "
                + "OR AnimalID LIKE ?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, "%" + filtro + "%");
            pst.setString(2, "%" + filtro + "%");

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {

                AnimalOrderItem item =
                        new AnimalOrderItem();

                item.setOrderID(
                        rs.getInt("OrderID")
                );

                item.setAnimalID(
                        rs.getInt("AnimalID")
                );

                item.setCost(
                        rs.getDouble("Cost")
                );

                lista.add(item);
            }

        } catch (SQLException e) {

            System.err.println(
                    "Error al buscar items: "
                    + e.getMessage()
            );
        }

        return lista;
    }

    // ================= ACTUALIZAR =================
    public boolean actualizarItem(
            AnimalOrderItem item
    ) {

        String sql = "UPDATE AnimalOrderItem SET "
                + "Cost=? "
                + "WHERE OrderID=? "
                + "AND AnimalID=?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setDouble(1, item.getCost());

            pst.setInt(2, item.getOrderID());

            pst.setInt(3, item.getAnimalID());

            return pst.executeUpdate() > 0;

        } catch (SQLException e) {

            System.err.println(
                    "Error al actualizar item: "
                    + e.getMessage()
            );

            return false;
        }
    }

    // ================= ELIMINAR =================
    public boolean eliminarItem(
            int orderID,
            int animalID
    ) {

        String sql = "DELETE FROM AnimalOrderItem "
                + "WHERE OrderID=? "
                + "AND AnimalID=?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, orderID);

            pst.setInt(2, animalID);

            return pst.executeUpdate() > 0;

        } catch (SQLException e) {

            System.err.println(
                    "Error al eliminar item: "
                    + e.getMessage()
            );

            return false;
        }
    }
}