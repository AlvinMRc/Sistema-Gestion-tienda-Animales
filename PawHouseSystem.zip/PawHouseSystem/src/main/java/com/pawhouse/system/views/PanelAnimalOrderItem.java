package com.pawhouse.system.views;

import com.pawhouse.system.dao.AnimalOrderItemDAO;
import com.pawhouse.system.models.AnimalOrderItem;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelAnimalOrderItem extends JPanel {

    private JTextField txtOrderID, txtAnimalID, txtCost, txtBuscar;
    private JButton btnRegistrar, btnActualizar, btnEliminar;
    private JTable table;
    private DefaultTableModel modeloTabla;
    private AnimalOrderItemDAO itemDAO;
    private int orderIDSeleccionado = -1;
    private int animalIDSeleccionado = -1;
    private final boolean esAdmin;

    public PanelAnimalOrderItem(String rol) {
        this.esAdmin = DashboardForm.esRolAdmin(rol);
        itemDAO = new AnimalOrderItemDAO();
        construirUI();
        listarItems();
    }

    public PanelAnimalOrderItem() { this("ADMIN"); }

    private void construirUI() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(35, 35, 35));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // ================= BUSCADOR =================
        JPanel panelBuscar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBuscar.setBackground(new Color(35, 35, 35));
        panelBuscar.add(crearLabel("Buscar:"));
        txtBuscar = new JTextField(20);
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override public void keyReleased(java.awt.event.KeyEvent evt) { listarItems(); }
        });
        panelBuscar.add(txtBuscar);
        add(panelBuscar, BorderLayout.NORTH);

        // ================= PANEL CENTRAL =================
        JPanel panelCentro = new JPanel(new GridLayout(1, 2, 15, 0));
        panelCentro.setBackground(new Color(35, 35, 35));

        // ================= TABLA =================
        modeloTabla = new DefaultTableModel(new Object[]{"OrderID","AnimalID","Cost"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(modeloTabla);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(25);
        table.setSelectionBackground(new Color(244, 162, 97, 80));
        table.getSelectionModel().addListSelectionListener(e -> llenarFormularioDesdeTabla());
        panelCentro.add(new JScrollPane(table));

        // ================= FORMULARIO =================
        JPanel formPanel = new JPanel(new GridLayout(7, 2, 5, 8));
        formPanel.setBackground(new Color(45, 45, 45));
        formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(70, 70, 70)),
                "Datos del Ítem", 0, 0,
                new Font("Segoe UI", Font.BOLD, 14), Color.WHITE));

        formPanel.add(crearLabel("Order ID:"));  txtOrderID  = new JTextField(); formPanel.add(txtOrderID);
        formPanel.add(crearLabel("Animal ID:")); txtAnimalID = new JTextField(); formPanel.add(txtAnimalID);
        formPanel.add(crearLabel("Cost:"));      txtCost     = new JTextField(); formPanel.add(txtCost);

        formPanel.add(new JLabel("")); formPanel.add(new JLabel(""));

        btnRegistrar  = crearBoton("Registrar",  new Color(46, 204, 113),  e -> registrar());
        btnActualizar = crearBoton("Actualizar",  new Color(244, 162, 97), e -> actualizar());
        btnEliminar   = crearBoton("Eliminar",    new Color(231, 76, 60),  e -> eliminar());

        formPanel.add(btnRegistrar);
        formPanel.add(btnActualizar);
        formPanel.add(btnEliminar);

        if (!esAdmin) {
            btnRegistrar.setEnabled(false);
            btnActualizar.setEnabled(false);
            btnEliminar.setEnabled(false);
            String tip = "Solo disponible para administradores";
            btnRegistrar.setToolTipText(tip);
            btnActualizar.setToolTipText(tip);
            btnEliminar.setToolTipText(tip);
        }

        panelCentro.add(formPanel);
        add(panelCentro, BorderLayout.CENTER);
    }

    private void registrar() {
        try {
            AnimalOrderItem item = new AnimalOrderItem(
                    Integer.parseInt(txtOrderID.getText()),
                    Integer.parseInt(txtAnimalID.getText()),
                    Double.parseDouble(txtCost.getText()));
            if (itemDAO.registrarItem(item)) { listarItems(); limpiarCampos(); }
            else JOptionPane.showMessageDialog(this,
                    "No se pudo registrar.\nVerifique que el OrderID y AnimalID existan.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor verifique los campos numéricos.", "Datos inválidos", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void actualizar() {
        if (orderIDSeleccionado <= 0 || animalIDSeleccionado <= 0) return;
        try {
            AnimalOrderItem item = new AnimalOrderItem(
                    orderIDSeleccionado, animalIDSeleccionado,
                    Double.parseDouble(txtCost.getText()));
            if (itemDAO.actualizarItem(item)) { listarItems(); limpiarCampos(); }
            else JOptionPane.showMessageDialog(this, "No se pudo actualizar el ítem.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor verifique los campos numéricos.", "Datos inválidos", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void eliminar() {
        if (orderIDSeleccionado <= 0 || animalIDSeleccionado <= 0) return;
        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Seguro que desea eliminar este ítem?",
                "Advertencia", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (itemDAO.eliminarItem(orderIDSeleccionado, animalIDSeleccionado)) {
                listarItems(); limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo eliminar el ítem.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void listarItems() {
        modeloTabla.setRowCount(0);
        List<AnimalOrderItem> lista = itemDAO.buscarItems(txtBuscar.getText());
        for (AnimalOrderItem item : lista) {
            modeloTabla.addRow(new Object[]{item.getOrderID(), item.getAnimalID(), item.getCost()});
        }
    }

    private void llenarFormularioDesdeTabla() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            orderIDSeleccionado  = (int) modeloTabla.getValueAt(row, 0);
            animalIDSeleccionado = (int) modeloTabla.getValueAt(row, 1);
            txtOrderID.setText(modeloTabla.getValueAt(row, 0).toString());
            txtAnimalID.setText(modeloTabla.getValueAt(row, 1).toString());
            txtCost.setText(modeloTabla.getValueAt(row, 2).toString());
        }
    }

    private void limpiarCampos() {
        orderIDSeleccionado = -1; animalIDSeleccionado = -1;
        txtOrderID.setText(""); txtAnimalID.setText(""); txtCost.setText("");
    }

    private JLabel crearLabel(String text) {
        JLabel lbl = new JLabel(text); lbl.setForeground(Color.WHITE); return lbl;
    }

    private JButton crearBoton(String text, Color bg, java.awt.event.ActionListener action) {
        JButton btn = new JButton(text);
        btn.setBackground(bg); btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false); btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setMargin(new Insets(5, 15, 5, 15));
        btn.putClientProperty("FlatLaf.style", String.format(
                "background: #%02x%02x%02x; foreground: #ffffff; font: bold 12 \'Segoe UI\'; arc: 16",
                bg.getRed(), bg.getGreen(), bg.getBlue()));
        btn.addActionListener(action);
        return btn;
    }
}