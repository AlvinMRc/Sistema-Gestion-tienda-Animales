package com.pawhouse.system.views;

import com.pawhouse.system.dao.EmployeeDAO;
import com.pawhouse.system.models.Employee;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelEmployee extends JPanel {

    private JTextField txtEmployeeID, txtLastName, txtFirstName, txtPhone,
            txtAddress, txtZipCode, txtCityID, txtTaxPayerID,
            txtDateHired, txtDateReleased, txtManagerID,
            txtEmployeeLevel, txtTitle, txtBuscar;

    private JButton btnRegistrar, btnActualizar, btnEliminar;
    private JTable table;
    private DefaultTableModel modeloTabla;
    private EmployeeDAO employeeDAO;
    private int idSeleccionado = -1;
    private final boolean esAdmin;

    public PanelEmployee(String rol) {
        this.esAdmin = DashboardForm.esRolAdmin(rol);
        employeeDAO = new EmployeeDAO();
        construirUI();
        listarEmpleados();
    }

    public PanelEmployee() { this("ADMIN"); }

    private void construirUI() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(35, 35, 35));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // ================= BUSCADOR =================
        JPanel panelBuscar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBuscar.setBackground(new Color(35, 35, 35));
        panelBuscar.add(crearLabel("Buscar:"));
        txtBuscar = new JTextField(20);
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override public void keyReleased(java.awt.event.KeyEvent evt) { listarEmpleados(); }
        });
        panelBuscar.add(txtBuscar);
        add(panelBuscar, BorderLayout.NORTH);

        // ================= PANEL CENTRAL =================
        JPanel panelCentro = new JPanel(new GridLayout(1, 2, 15, 0));
        panelCentro.setBackground(new Color(35, 35, 35));

        // ================= TABLA =================
        modeloTabla = new DefaultTableModel(
                new Object[]{"ID","Apellido","Nombre","Teléfono","Dirección",
                             "ZipCode","CityID","TaxPayerID","Fecha Contrato",
                             "Fecha Salida","ManagerID","Nivel","Título"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(modeloTabla);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(25);
        table.setSelectionBackground(new Color(244, 162, 97, 80));
        table.getSelectionModel().addListSelectionListener(e -> llenarFormularioDesdeTabla());
        panelCentro.add(new JScrollPane(table));

        // ================= FORMULARIO =================
        JPanel formPanel = new JPanel(new GridLayout(15, 2, 5, 8));
        formPanel.setBackground(new Color(45, 45, 45));
        formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(70, 70, 70)),
                "Datos del Empleado", 0, 0,
                new Font("Segoe UI", Font.BOLD, 14), Color.WHITE));

        formPanel.add(crearLabel("Employee ID:"));    txtEmployeeID    = new JTextField(); formPanel.add(txtEmployeeID);
        formPanel.add(crearLabel("Last Name:"));      txtLastName      = new JTextField(); formPanel.add(txtLastName);
        formPanel.add(crearLabel("First Name:"));     txtFirstName     = new JTextField(); formPanel.add(txtFirstName);
        formPanel.add(crearLabel("Phone:"));          txtPhone         = new JTextField(); formPanel.add(txtPhone);
        formPanel.add(crearLabel("Address:"));        txtAddress       = new JTextField(); formPanel.add(txtAddress);
        formPanel.add(crearLabel("Zip Code:"));       txtZipCode       = new JTextField(); formPanel.add(txtZipCode);
        formPanel.add(crearLabel("City ID:"));        txtCityID        = new JTextField(); formPanel.add(txtCityID);
        formPanel.add(crearLabel("TaxPayer ID:"));    txtTaxPayerID    = new JTextField(); formPanel.add(txtTaxPayerID);
        formPanel.add(crearLabel("Date Hired:"));     txtDateHired     = new JTextField(); formPanel.add(txtDateHired);
        formPanel.add(crearLabel("Date Released:"));  txtDateReleased  = new JTextField(); formPanel.add(txtDateReleased);
        formPanel.add(crearLabel("Manager ID:"));     txtManagerID     = new JTextField(); formPanel.add(txtManagerID);
        formPanel.add(crearLabel("Employee Level:")); txtEmployeeLevel = new JTextField(); formPanel.add(txtEmployeeLevel);
        formPanel.add(crearLabel("Title:"));          txtTitle         = new JTextField(); formPanel.add(txtTitle);

        formPanel.add(new JLabel("")); formPanel.add(new JLabel(""));

        btnRegistrar  = crearBoton("Registrar",  new Color(46, 204, 113),  e -> registrar());
        btnActualizar = crearBoton("Actualizar",  new Color(244, 162, 97), e -> actualizar());
        btnEliminar   = crearBoton("Eliminar",    new Color(231, 76, 60),  e -> eliminar());

        formPanel.add(btnRegistrar);
        formPanel.add(btnActualizar);
        formPanel.add(btnEliminar);

        if (!esAdmin) {
            btnRegistrar.setEnabled(false);
            btnActualizar.setEnabled(false);
            btnEliminar.setEnabled(false);
            String tip = "Solo disponible para administradores";
            btnRegistrar.setToolTipText(tip);
            btnActualizar.setToolTipText(tip);
            btnEliminar.setToolTipText(tip);
        }

        panelCentro.add(formPanel);
        add(panelCentro, BorderLayout.CENTER);
    }

    // ================= REGISTRAR =================
    private void registrar() {
        try {
            Employee e = new Employee(
                    txtLastName.getText(), txtFirstName.getText(), txtPhone.getText(),
                    txtAddress.getText(), txtZipCode.getText(),
                    Integer.parseInt(txtCityID.getText()), txtTaxPayerID.getText(),
                    txtDateHired.getText(), txtDateReleased.getText(),
                    Integer.parseInt(txtManagerID.getText()),
                    Integer.parseInt(txtEmployeeLevel.getText()), txtTitle.getText());
            e.setEmployeeID(Integer.parseInt(txtEmployeeID.getText()));
            if (employeeDAO.registrarEmpleado(e)) { listarEmpleados(); limpiarCampos(); }
            else JOptionPane.showMessageDialog(this, "No se pudo registrar el empleado.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor verifique los campos numéricos.", "Datos inválidos", JOptionPane.WARNING_MESSAGE);
        }
    }

    // ================= ACTUALIZAR =================
    private void actualizar() {
        if (idSeleccionado <= 0) return;
        try {
            Employee e = new Employee(
                    txtLastName.getText(), txtFirstName.getText(), txtPhone.getText(),
                    txtAddress.getText(), txtZipCode.getText(),
                    Integer.parseInt(txtCityID.getText()), txtTaxPayerID.getText(),
                    txtDateHired.getText(), txtDateReleased.getText(),
                    Integer.parseInt(txtManagerID.getText()),
                    Integer.parseInt(txtEmployeeLevel.getText()), txtTitle.getText());
            e.setEmployeeID(idSeleccionado);
            if (employeeDAO.actualizarEmpleado(e)) { listarEmpleados(); limpiarCampos(); }
            else JOptionPane.showMessageDialog(this, "No se pudo actualizar el empleado.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor verifique los campos numéricos.", "Datos inválidos", JOptionPane.WARNING_MESSAGE);
        }
    }

    // ================= ELIMINAR =================
    private void eliminar() {
        if (idSeleccionado <= 0) return;
        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Seguro que desea eliminar este empleado?\n" +
                "Si tiene órdenes o ventas asociadas no se podrá eliminar.",
                "Advertencia", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (employeeDAO.eliminarEmpleado(idSeleccionado)) {
                listarEmpleados(); limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this,
                        "No se puede eliminar este empleado.\n" +
                        "Tiene órdenes o ventas registradas a su nombre.\n\n" +
                        "Elimine primero los registros relacionados.",
                        "Error de integridad referencial",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // ================= LISTAR =================
    private void listarEmpleados() {
        modeloTabla.setRowCount(0);
        List<Employee> lista = employeeDAO.buscarEmpleados(txtBuscar.getText());
        for (Employee e : lista) {
            modeloTabla.addRow(new Object[]{
                e.getEmployeeID(), e.getLastName(), e.getFirstName(), e.getPhone(),
                e.getAddress(), e.getZipCode(), e.getCityID(), e.getTaxPayerID(),
                e.getDateHired(), e.getDateReleased(), e.getManagerID(),
                e.getEmployeeLevel(), e.getTitle()
            });
        }
    }

    // ================= LLENAR FORM =================
    private void llenarFormularioDesdeTabla() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            idSeleccionado = (int) modeloTabla.getValueAt(row, 0);
            txtEmployeeID.setText(modeloTabla.getValueAt(row, 0).toString());
            txtLastName.setText(modeloTabla.getValueAt(row, 1).toString());
            txtFirstName.setText(modeloTabla.getValueAt(row, 2).toString());
            txtPhone.setText(modeloTabla.getValueAt(row, 3).toString());
            txtAddress.setText(modeloTabla.getValueAt(row, 4).toString());
            txtZipCode.setText(modeloTabla.getValueAt(row, 5).toString());
            txtCityID.setText(modeloTabla.getValueAt(row, 6).toString());
            txtTaxPayerID.setText(modeloTabla.getValueAt(row, 7).toString());
            txtDateHired.setText(modeloTabla.getValueAt(row, 8).toString());
            txtDateReleased.setText(modeloTabla.getValueAt(row, 9).toString());
            txtManagerID.setText(modeloTabla.getValueAt(row, 10).toString());
            txtEmployeeLevel.setText(modeloTabla.getValueAt(row, 11).toString());
            txtTitle.setText(modeloTabla.getValueAt(row, 12).toString());
        }
    }

    // ================= LIMPIAR =================
    private void limpiarCampos() {
        idSeleccionado = -1;
        txtEmployeeID.setText(""); txtLastName.setText(""); txtFirstName.setText("");
        txtPhone.setText(""); txtAddress.setText(""); txtZipCode.setText("");
        txtCityID.setText(""); txtTaxPayerID.setText(""); txtDateHired.setText("");
        txtDateReleased.setText(""); txtManagerID.setText("");
        txtEmployeeLevel.setText(""); txtTitle.setText("");
    }

    private JLabel crearLabel(String text) {
        JLabel lbl = new JLabel(text); lbl.setForeground(Color.WHITE); return lbl;
    }

    private JButton crearBoton(String text, Color bg, java.awt.event.ActionListener action) {
        JButton btn = new JButton(text);
        btn.setBackground(bg); btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false); btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setMargin(new Insets(5, 15, 5, 15));
        btn.putClientProperty("FlatLaf.style", String.format(
                "background: #%02x%02x%02x; foreground: #ffffff; font: bold 12 \'Segoe UI\'; arc: 16",
                bg.getRed(), bg.getGreen(), bg.getBlue()));
        btn.addActionListener(action);
        return btn;
    }
}