
package com.pawhouse.system.models;

public class Employee {

    private int employeeID;
    private String lastName;
    private String firstName;
    private String phone;
    private String address;
    private String zipCode;
    private int cityID;
    private String taxPayerID;
    private String dateHired;
    private String dateReleased;
    private int managerID;
    private int employeeLevel;
    private String title;

    // Constructor vacío
    public Employee() {}

    // Constructor con parámetros
    public Employee(String lastName, String firstName,
                    String phone, String address,
                    String zipCode, int cityID,
                    String taxPayerID, String dateHired,
                    String dateReleased, int managerID,
                    int employeeLevel, String title) {

        this.lastName = lastName;
        this.firstName = firstName;
        this.phone = phone;
        this.address = address;
        this.zipCode = zipCode;
        this.cityID = cityID;
        this.taxPayerID = taxPayerID;
        this.dateHired = dateHired;
        this.dateReleased = dateReleased;
        this.managerID = managerID;
        this.employeeLevel = employeeLevel;
        this.title = title;
    }

    // Getters y Setters

    public int getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(int employeeID) {
        this.employeeID = employeeID;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public int getCityID() {
        return cityID;
    }

    public void setCityID(int cityID) {
        this.cityID = cityID;
    }

    public String getTaxPayerID() {
        return taxPayerID;
    }

    public void setTaxPayerID(String taxPayerID) {
        this.taxPayerID = taxPayerID;
    }

    public String getDateHired() {
        return dateHired;
    }

    public void setDateHired(String dateHired) {
        this.dateHired = dateHired;
    }

    public String getDateReleased() {
        return dateReleased;
    }

    public void setDateReleased(String dateReleased) {
        this.dateReleased = dateReleased;
    }

    public int getManagerID() {
        return managerID;
    }

    public void setManagerID(int managerID) {
        this.managerID = managerID;
    }

    public int getEmployeeLevel() {
        return employeeLevel;
    }

    public void setEmployeeLevel(int employeeLevel) {
        this.employeeLevel = employeeLevel;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}