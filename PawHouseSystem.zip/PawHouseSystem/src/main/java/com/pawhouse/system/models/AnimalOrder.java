
package com.pawhouse.system.models;

public class AnimalOrder {

    private int orderID;
    private String orderDate;
    private String receiveDate;
    private int supplierID;
    private double shippingCost;
    private int employeeID;

    // Constructor vacío
    public AnimalOrder() {}

    // Constructor con parámetros
    public AnimalOrder(String orderDate, String receiveDate,
                       int supplierID, double shippingCost,
                       int employeeID) {

        this.orderDate = orderDate;
        this.receiveDate = receiveDate;
        this.supplierID = supplierID;
        this.shippingCost = shippingCost;
        this.employeeID = employeeID;
    }

    // Getters y Setters

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getReceiveDate() {
        return receiveDate;
    }

    public void setReceiveDate(String receiveDate) {
        this.receiveDate = receiveDate;
    }

    public int getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(int supplierID) {
        this.supplierID = supplierID;
    }

    public double getShippingCost() {
        return shippingCost;
    }

    public void setShippingCost(double shippingCost) {
        this.shippingCost = shippingCost;
    }

    public int getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(int employeeID) {
        this.employeeID = employeeID;
    }
}