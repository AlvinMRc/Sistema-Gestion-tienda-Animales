
package com.pawhouse.system.dao;
import com.pawhouse.system.config.DatabaseConnection;
import com.pawhouse.system.models.SaleAnimal;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SaleAnimalDAO {

    // ================= REGISTRAR =================
    public boolean registrarSaleAnimal(SaleAnimal sa) {

        String sql = "INSERT INTO SaleAnimal "
                + "(SaleID, AnimalID, SalePrice) "
                + "VALUES (?, ?, ?)";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, sa.getSaleID());
            pst.setInt(2, sa.getAnimalID());
            pst.setDouble(3, sa.getSalePrice());

            return pst.executeUpdate() > 0;

        } catch (SQLException ex) {

            System.err.println(
                    "Error al registrar SaleAnimal: "
                    + ex.getMessage()
            );

            return false;
        }
    }

    // ================= BUSCAR =================
    public List<SaleAnimal> buscarSaleAnimals(
            String filtro
    ) {

        List<SaleAnimal> lista =
                new ArrayList<>();

        String sql = "SELECT * FROM SaleAnimal "
                + "WHERE SaleID LIKE ? "
                + "OR AnimalID LIKE ?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1,
                    "%" + filtro + "%");

            pst.setString(2,
                    "%" + filtro + "%");

            ResultSet rs =
                    pst.executeQuery();

            while (rs.next()) {

                SaleAnimal sa =
                        new SaleAnimal();

                sa.setSaleID(
                        rs.getInt("SaleID")
                );

                sa.setAnimalID(
                        rs.getInt("AnimalID")
                );

                sa.setSalePrice(
                        rs.getDouble("SalePrice")
                );

                lista.add(sa);
            }

        } catch (SQLException ex) {

            System.err.println(
                    "Error al buscar SaleAnimal: "
                    + ex.getMessage()
            );
        }

        return lista;
    }

    // ================= ACTUALIZAR =================
    public boolean actualizarSaleAnimal(
            SaleAnimal sa
    ) {

        String sql = "UPDATE SaleAnimal SET "
                + "SalePrice=? "
                + "WHERE SaleID=? "
                + "AND AnimalID=?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setDouble(1,
                    sa.getSalePrice());

            pst.setInt(2,
                    sa.getSaleID());

            pst.setInt(3,
                    sa.getAnimalID());

            return pst.executeUpdate() > 0;

        } catch (SQLException ex) {

            System.err.println(
                    "Error al actualizar SaleAnimal: "
                    + ex.getMessage()
            );

            return false;
        }
    }

    // ================= ELIMINAR =================
    public boolean eliminarSaleAnimal(
            int saleID,
            int animalID
    ) {

        String sql = "DELETE FROM SaleAnimal "
                + "WHERE SaleID=? "
                + "AND AnimalID=?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, saleID);

            pst.setInt(2, animalID);

            return pst.executeUpdate() > 0;

        } catch (SQLException ex) {

            System.err.println(
                    "Error al eliminar SaleAnimal: "
                    + ex.getMessage()
            );

            return false;
        }
    }
}