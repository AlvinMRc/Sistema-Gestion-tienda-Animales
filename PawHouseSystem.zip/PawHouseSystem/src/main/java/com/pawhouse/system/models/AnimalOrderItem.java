
package com.pawhouse.system.models;

public class AnimalOrderItem {

    private int orderID;
    private int animalID;
    private double cost;

    // Constructor vacío
    public AnimalOrderItem() {}

    // Constructor con parámetros
    public AnimalOrderItem(int orderID, int animalID, double cost) {
        this.orderID = orderID;
        this.animalID = animalID;
        this.cost = cost;
    }

    // Getters y Setters

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public int getAnimalID() {
        return animalID;
    }

    public void setAnimalID(int animalID) {
        this.animalID = animalID;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }
}