package com.pawhouse.system.views;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.URISyntaxException;
import java.nio.file.*;

public class PanelAyuda extends JPanel {

    public PanelAyuda() {
        setLayout(new BorderLayout());
        setBackground(new Color(35, 35, 35));

        // ================= TITULO =================
        JLabel titulo = new JLabel("CENTRO DE AYUDA", SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titulo.setForeground(Color.WHITE);
        titulo.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        add(titulo, BorderLayout.NORTH);

        // ================= AREA TEXTO =================
        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setBackground(new Color(45, 45, 45));
        area.setForeground(Color.WHITE);
        area.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        area.setMargin(new Insets(15, 15, 15, 15));
        area.setText(
                "BIENVENIDO AL SISTEMA PAW HOUSE\n\n"
                + "FUNCIONES PRINCIPALES:\n\n"
                + "• Registrar datos.\n"
                + "• Actualizar registros.\n"
                + "• Eliminar registros.\n"
                + "• Buscar información.\n"
                + "• Gestionar animales.\n"
                + "• Gestionar ventas.\n"
                + "• Gestionar empleados.\n\n"
                + "TIPOS DE USUARIO:\n\n"
                + "ADMIN:\n"
                + "Tiene acceso completo.\n\n"
                + "EMPLEADO:\n"
                + "Solo puede visualizar información.\n\n"
                + "SOPORTE:\n"
                + "pawhouse@gmail.com"
        );

        JScrollPane scroll = new JScrollPane(area);
        add(scroll, BorderLayout.CENTER);

        // ================= PANEL INFERIOR =================
        JPanel panelSur = new JPanel(new BorderLayout());
        panelSur.setBackground(new Color(35, 35, 35));

        // -- Botón Manual PDF --
        JButton btnManual = new JButton("  \uD83D\uDCC4  Ver Manual de Usuario (PDF)");
        btnManual.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnManual.setBackground(new Color(244, 162, 97));
        btnManual.setForeground(Color.WHITE);
        btnManual.setFocusPainted(false);
        btnManual.setBorderPainted(false);
        btnManual.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnManual.setMargin(new Insets(10, 20, 10, 20));
        btnManual.putClientProperty("FlatLaf.style",
                "background: #f4a261; foreground: #ffffff; font: bold 14 'Segoe UI'; arc: 16");
        btnManual.addActionListener(e -> abrirManualPDF());

        JPanel wrapBtn = new JPanel(new FlowLayout(FlowLayout.CENTER));
        wrapBtn.setBackground(new Color(35, 35, 35));
        wrapBtn.setBorder(BorderFactory.createEmptyBorder(10, 0, 5, 0));
        wrapBtn.add(btnManual);
        panelSur.add(wrapBtn, BorderLayout.CENTER);

        // -- Icono ? --
        JLabel icono = new JLabel("?", SwingConstants.CENTER);
        icono.setFont(new Font("Segoe UI", Font.BOLD, 50));
        icono.setForeground(new Color(192, 57, 43));
        icono.setBorder(BorderFactory.createEmptyBorder(5, 10, 20, 10));
        panelSur.add(icono, BorderLayout.SOUTH);

        add(panelSur, BorderLayout.SOUTH);
    }

    // ================= ABRIR MANUAL PDF =================
    private void abrirManualPDF() {
        if (!Desktop.isDesktopSupported()) {
            JOptionPane.showMessageDialog(this,
                    "Su sistema no soporta apertura automática de archivos.\n"
                    + "Busque el archivo 'Manual_PAW_HOUSE.pdf' en la carpeta del programa.",
                    "No disponible", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        File pdf = encontrarPDF();

        if (pdf != null && pdf.exists()) {
            try {
                Desktop.getDesktop().open(pdf);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this,
                        "No se pudo abrir el PDF:\n" + ex.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            // Mostrar todas las rutas buscadas para ayudar al usuario
            String basePath = obtenerDirectorioBase();
            JOptionPane.showMessageDialog(this,
                    "No se encontró el archivo 'Manual_PAW_HOUSE.pdf'.\n\n"
                    + "Colóquelo en cualquiera de estas rutas:\n"
                    + "  • " + basePath + File.separator + "Manual_PAW_HOUSE.pdf\n"
                    + "  • " + basePath + File.separator + "docs" + File.separator + "Manual_PAW_HOUSE.pdf",
                    "Archivo no encontrado", JOptionPane.WARNING_MESSAGE);
        }
    }

    /**
     * Obtiene el directorio base donde está el .jar o las clases compiladas.
     */
    private String obtenerDirectorioBase() {
        try {
            // Ruta del .jar o carpeta de clases
            File jarDir = new File(
                PanelAyuda.class.getProtectionDomain()
                    .getCodeSource().getLocation().toURI()
            );
            // Si es un .jar, subimos al directorio padre
            if (jarDir.isFile()) {
                return jarDir.getParent();
            }
            // Si son clases sueltas (IDE), normalmente .../build/classes →
            // subimos dos niveles para llegar a la raíz del proyecto
            File parent = jarDir.getParentFile(); // build
            if (parent != null) parent = parent.getParentFile(); // raíz proyecto
            return (parent != null) ? parent.getAbsolutePath() : jarDir.getAbsolutePath();
        } catch (URISyntaxException e) {
            return System.getProperty("user.dir");
        }
    }

    /**
     * Intenta localizar el PDF en varias rutas posibles.
     */
    private File encontrarPDF() {
        final String nombre = "Manual_PAW_HOUSE.pdf";
        String base = obtenerDirectorioBase();

        // Lista de candidatos en orden de prioridad
        String[] candidatos = {
            base + File.separator + nombre,                         // raíz del proyecto / junto al jar
            base + File.separator + "dist" + File.separator + nombre, // carpeta dist de NetBeans
            base + File.separator + "docs" + File.separator + nombre,
            base + File.separator + "resources" + File.separator + nombre,
            System.getProperty("user.dir") + File.separator + nombre, // directorio de trabajo actual
            System.getProperty("user.dir") + File.separator + "docs" + File.separator + nombre,
        };

        for (String ruta : candidatos) {
            File f = new File(ruta);
            if (f.exists()) return f;
        }

        // Último recurso: recurso empaquetado dentro del jar
        try (InputStream is = getClass().getResourceAsStream("/docs/" + nombre)) {
            if (is != null) {
                Path tmp = Files.createTempFile("PawHouseManual_", ".pdf");
                Files.copy(is, tmp, StandardCopyOption.REPLACE_EXISTING);
                tmp.toFile().deleteOnExit();
                return tmp.toFile();
            }
        } catch (IOException ex) {
            // ignorar
        }

        return null;
    }
}