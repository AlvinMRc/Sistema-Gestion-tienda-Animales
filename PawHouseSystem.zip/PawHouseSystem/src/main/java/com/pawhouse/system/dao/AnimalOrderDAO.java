
package com.pawhouse.system.dao;

import com.pawhouse.system.config.DatabaseConnection;
import com.pawhouse.system.models.AnimalOrder;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AnimalOrderDAO {

    // ================= REGISTRAR =================
    public boolean registrarOrden(AnimalOrder o) {

        String sql = "INSERT INTO AnimalOrder "
                + "(OrderID, OrderDate, ReceiveDate, SupplierID, ShippingCost, EmployeeID) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, o.getOrderID());
            pst.setString(2, o.getOrderDate());
            pst.setString(3, o.getReceiveDate());
            pst.setInt(4, o.getSupplierID());
            pst.setDouble(5, o.getShippingCost());
            pst.setInt(6, o.getEmployeeID());

            return pst.executeUpdate() > 0;

        } catch (SQLException e) {

            System.err.println("Error al registrar orden: " + e.getMessage());
            return false;
        }
    }

    // ================= BUSCAR =================
    public List<AnimalOrder> buscarOrdenes(String filtro) {

        List<AnimalOrder> lista = new ArrayList<>();

        String sql = "SELECT * FROM AnimalOrder "
                + "WHERE OrderDate LIKE ? "
                + "OR SupplierID LIKE ?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, "%" + filtro + "%");
            pst.setString(2, "%" + filtro + "%");

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {

                AnimalOrder o = new AnimalOrder();

                o.setOrderID(rs.getInt("OrderID"));
                o.setOrderDate(rs.getString("OrderDate"));
                o.setReceiveDate(rs.getString("ReceiveDate"));
                o.setSupplierID(rs.getInt("SupplierID"));
                o.setShippingCost(rs.getDouble("ShippingCost"));
                o.setEmployeeID(rs.getInt("EmployeeID"));

                lista.add(o);
            }

        } catch (SQLException e) {

            System.err.println("Error al buscar órdenes: " + e.getMessage());
        }

        return lista;
    }

    // ================= ACTUALIZAR =================
    public boolean actualizarOrden(AnimalOrder o) {

        String sql = "UPDATE AnimalOrder SET "
                + "OrderDate=?, "
                + "ReceiveDate=?, "
                + "SupplierID=?, "
                + "ShippingCost=?, "
                + "EmployeeID=? "
                + "WHERE OrderID=?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, o.getOrderDate());
            pst.setString(2, o.getReceiveDate());
            pst.setInt(3, o.getSupplierID());
            pst.setDouble(4, o.getShippingCost());
            pst.setInt(5, o.getEmployeeID());
            pst.setInt(6, o.getOrderID());

            return pst.executeUpdate() > 0;

        } catch (SQLException e) {

            System.err.println("Error al actualizar orden: " + e.getMessage());
            return false;
        }
    }

    // ================= ELIMINAR =================
    public boolean eliminarOrden(int orderID) {

        String sql = "DELETE FROM AnimalOrder WHERE OrderID=?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, orderID);

            return pst.executeUpdate() > 0;

        } catch (SQLException e) {

            System.err.println("Error al eliminar orden: " + e.getMessage());
            return false;
        }
    }
}