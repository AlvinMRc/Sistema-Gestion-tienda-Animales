
package com.pawhouse.system.dao;
import com.pawhouse.system.config.DatabaseConnection;
import com.pawhouse.system.models.Employee;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {

    // ================= REGISTRAR =================
    public boolean registrarEmpleado(Employee e) {

        String sql = "INSERT INTO Employee "
                + "(EmployeeID, LastName, FirstName, Phone, Address, "
                + "ZipCode, CityID, TaxPayerID, DateHired, "
                + "DateReleased, ManagerID, EmployeeLevel, Title) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, e.getEmployeeID());
            pst.setString(2, e.getLastName());
            pst.setString(3, e.getFirstName());
            pst.setString(4, e.getPhone());
            pst.setString(5, e.getAddress());
            pst.setString(6, e.getZipCode());
            pst.setInt(7, e.getCityID());
            pst.setString(8, e.getTaxPayerID());
            pst.setString(9, e.getDateHired());
            pst.setString(10, e.getDateReleased());
            pst.setInt(11, e.getManagerID());
            pst.setInt(12, e.getEmployeeLevel());
            pst.setString(13, e.getTitle());

            return pst.executeUpdate() > 0;

        } catch (SQLException ex) {

            System.err.println(
                    "Error al registrar empleado: "
                    + ex.getMessage()
            );

            return false;
        }
    }

    // ================= BUSCAR =================
    public List<Employee> buscarEmpleados(String filtro) {

        List<Employee> lista = new ArrayList<>();

        String sql = "SELECT * FROM Employee "
                + "WHERE FirstName LIKE ? "
                + "OR LastName LIKE ? "
                + "OR Title LIKE ?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, "%" + filtro + "%");
            pst.setString(2, "%" + filtro + "%");
            pst.setString(3, "%" + filtro + "%");

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {

                Employee e = new Employee();

                e.setEmployeeID(
                        rs.getInt("EmployeeID")
                );

                e.setLastName(
                        rs.getString("LastName")
                );

                e.setFirstName(
                        rs.getString("FirstName")
                );

                e.setPhone(
                        rs.getString("Phone")
                );

                e.setAddress(
                        rs.getString("Address")
                );

                e.setZipCode(
                        rs.getString("ZipCode")
                );

                e.setCityID(
                        rs.getInt("CityID")
                );

                e.setTaxPayerID(
                        rs.getString("TaxPayerID")
                );

                e.setDateHired(
                        rs.getString("DateHired")
                );

                e.setDateReleased(
                        rs.getString("DateReleased")
                );

                e.setManagerID(
                        rs.getInt("ManagerID")
                );

                e.setEmployeeLevel(
                        rs.getInt("EmployeeLevel")
                );

                e.setTitle(
                        rs.getString("Title")
                );

                lista.add(e);
            }

        } catch (SQLException ex) {

            System.err.println(
                    "Error al buscar empleados: "
                    + ex.getMessage()
            );
        }

        return lista;
    }

    // ================= ACTUALIZAR =================
    public boolean actualizarEmpleado(Employee e) {

        String sql = "UPDATE Employee SET "
                + "LastName=?, "
                + "FirstName=?, "
                + "Phone=?, "
                + "Address=?, "
                + "ZipCode=?, "
                + "CityID=?, "
                + "TaxPayerID=?, "
                + "DateHired=?, "
                + "DateReleased=?, "
                + "ManagerID=?, "
                + "EmployeeLevel=?, "
                + "Title=? "
                + "WHERE EmployeeID=?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, e.getLastName());
            pst.setString(2, e.getFirstName());
            pst.setString(3, e.getPhone());
            pst.setString(4, e.getAddress());
            pst.setString(5, e.getZipCode());
            pst.setInt(6, e.getCityID());
            pst.setString(7, e.getTaxPayerID());
            pst.setString(8, e.getDateHired());
            pst.setString(9, e.getDateReleased());
            pst.setInt(10, e.getManagerID());
            pst.setInt(11, e.getEmployeeLevel());
            pst.setString(12, e.getTitle());
            pst.setInt(13, e.getEmployeeID());

            return pst.executeUpdate() > 0;

        } catch (SQLException ex) {

            System.err.println(
                    "Error al actualizar empleado: "
                    + ex.getMessage()
            );

            return false;
        }
    }

    // ================= ELIMINAR =================
    public boolean eliminarEmpleado(int employeeID) {

        String sql = "DELETE FROM Employee "
                + "WHERE EmployeeID=?";

        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, employeeID);

            return pst.executeUpdate() > 0;

        } catch (SQLException ex) {

            System.err.println(
                    "Error al eliminar empleado: "
                    + ex.getMessage()
            );

            return false;
        }
    }
}