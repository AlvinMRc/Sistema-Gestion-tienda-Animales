
package com.pawhouse.system.models;

public class Animal {
    private int animalID;
    private String name;
    private String category;
    private String breed;
    private String dateBorn;
    private String gender;
    private String registered;
    private String color;
    private double listPrice;

    // Constructor vacío
    public Animal() {}

    // Constructor con parámetros
    public Animal(String name, String category, String breed, String dateBorn,
                  String gender, String registered, String color, double listPrice) {
        this.name = name;
        this.category = category;
        this.breed = breed;
        this.dateBorn = dateBorn;
        this.gender = gender;
        this.registered = registered;
        this.color = color;
        this.listPrice = listPrice;
    }

    // Getters y Setters
    public int getAnimalID() {
        return animalID;
    }

    public void setAnimalID(int animalID) {
        this.animalID = animalID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getDateBorn() {
        return dateBorn;
    }

    public void setDateBorn(String dateBorn) {
        this.dateBorn = dateBorn;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getRegistered() {
        return registered;
    }

    public void setRegistered(String registered) {
        this.registered = registered;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getListPrice() {
        return listPrice;
    }

    public void setListPrice(double listPrice) {
        this.listPrice = listPrice;
    }
}