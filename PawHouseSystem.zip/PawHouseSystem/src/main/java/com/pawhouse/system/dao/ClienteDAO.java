package com.pawhouse.system.dao;

import com.pawhouse.system.config.DatabaseConnection;
import com.pawhouse.system.models.Cliente;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {
    
    public boolean registrarCliente(Cliente c) {
        String sql = "INSERT INTO clientes (cedula, nombre, telefono, estado) VALUES (?, ?, ?, ?)";
        try (Connection con = DatabaseConnection.getConnection(); PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, c.getCedula()); pst.setString(2, c.getNombre()); pst.setString(3, c.getTelefono()); pst.setBoolean(4, c.isEstado());
            return pst.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println("Error al registrar: " + e.getMessage()); return false; }
    }

    public List<Cliente> buscarClientes(String filtro) {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT * FROM clientes WHERE cedula LIKE ? OR nombre LIKE ?";
        try (Connection con = DatabaseConnection.getConnection(); PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, "%" + filtro + "%"); pst.setString(2, "%" + filtro + "%");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Cliente c = new Cliente(); c.setId(rs.getInt("id")); c.setCedula(rs.getString("cedula")); c.setNombre(rs.getString("nombre")); c.setTelefono(rs.getString("telefono")); c.setEstado(rs.getBoolean("estado"));
                lista.add(c);
            }
        } catch (SQLException e) { System.err.println("Error al buscar: " + e.getMessage()); }
        return lista;
    }

    public boolean actualizarCliente(Cliente c) {
        String sql = "UPDATE clientes SET cedula=?, nombre=?, telefono=?, estado=? WHERE id=?";
        try (Connection con = DatabaseConnection.getConnection(); PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, c.getCedula()); pst.setString(2, c.getNombre()); pst.setString(3, c.getTelefono()); pst.setBoolean(4, c.isEstado()); pst.setInt(5, c.getId());
            return pst.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println("Error al actualizar: " + e.getMessage()); return false; }
    }

    public boolean eliminarCliente(int id) {
        String sql = "DELETE FROM clientes WHERE id=?";
        try (Connection con = DatabaseConnection.getConnection(); PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, id);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println("Error al eliminar: " + e.getMessage()); return false; }
    }

    public void cambiarEstadoCliente(int idSeleccionado, boolean estado) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}