package com.pawhouse.system.models;

public class Cliente {
    private int id;
    private String cedula;
    private String nombre;
    private String telefono;
    private boolean estado;

    // Constructor vacío, Constructor con parámetros, Getters y Setters
    public Cliente() {}

    public Cliente(String cedula, String nombre, String telefono, boolean estado) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.telefono = telefono;
        this.estado = estado;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public boolean isEstado() { return estado; }
    public void setEstado(boolean estado) { this.estado = estado; }
}