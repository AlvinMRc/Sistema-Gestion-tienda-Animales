package com.pawhouse.system.views;

import com.pawhouse.system.dao.SaleDAO;
import com.pawhouse.system.models.Sale;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelSale extends JPanel {

    private JTextField txtSaleID, txtSaleDate, txtEmployeeID,
            txtCustomerID, txtSalesTax, txtBuscar;

    private JButton btnRegistrar, btnActualizar, btnEliminar;
    private JTable table;
    private DefaultTableModel modeloTabla;
    private SaleDAO saleDAO;
    private int idSeleccionado = -1;
    private final boolean esAdmin;

    public PanelSale(String rol) {
        this.esAdmin = DashboardForm.esRolAdmin(rol);
        saleDAO = new SaleDAO();
        construirUI();
        listarSales();
    }

    public PanelSale() { this("ADMIN"); }

    private void construirUI() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(35, 35, 35));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // ================= BUSCADOR =================
        JPanel panelBuscar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBuscar.setBackground(new Color(35, 35, 35));
        panelBuscar.add(crearLabel("Buscar:"));
        txtBuscar = new JTextField(20);
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override public void keyReleased(java.awt.event.KeyEvent evt) { listarSales(); }
        });
        panelBuscar.add(txtBuscar);
        add(panelBuscar, BorderLayout.NORTH);

        // ================= PANEL CENTRAL =================
        JPanel panelCentro = new JPanel(new GridLayout(1, 2, 15, 0));
        panelCentro.setBackground(new Color(35, 35, 35));

        // ================= TABLA =================
        modeloTabla = new DefaultTableModel(
                new Object[]{"SaleID","SaleDate","EmployeeID","CustomerID","SalesTax"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(modeloTabla);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(25);
        table.setSelectionBackground(new Color(244, 162, 97, 80));
        table.getSelectionModel().addListSelectionListener(e -> llenarFormularioDesdeTabla());
        panelCentro.add(new JScrollPane(table));

        // ================= FORMULARIO =================
        JPanel formPanel = new JPanel(new GridLayout(9, 2, 5, 8));
        formPanel.setBackground(new Color(45, 45, 45));
        formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(70, 70, 70)),
                "Datos de la Venta", 0, 0,
                new Font("Segoe UI", Font.BOLD, 14), Color.WHITE));

        formPanel.add(crearLabel("Sale ID:"));      txtSaleID     = new JTextField(); formPanel.add(txtSaleID);
        formPanel.add(crearLabel("Sale Date:"));    txtSaleDate   = new JTextField(); formPanel.add(txtSaleDate);
        formPanel.add(crearLabel("Employee ID:"));  txtEmployeeID = new JTextField(); formPanel.add(txtEmployeeID);
        formPanel.add(crearLabel("Customer ID:"));  txtCustomerID = new JTextField(); formPanel.add(txtCustomerID);
        formPanel.add(crearLabel("Sales Tax:"));    txtSalesTax   = new JTextField(); formPanel.add(txtSalesTax);

        formPanel.add(new JLabel("")); formPanel.add(new JLabel(""));

        btnRegistrar  = crearBoton("Registrar",  new Color(46, 204, 113),  e -> registrar());
        btnActualizar = crearBoton("Actualizar",  new Color(244, 162, 97), e -> actualizar());
        btnEliminar   = crearBoton("Eliminar",    new Color(231, 76, 60),  e -> eliminar());

        formPanel.add(btnRegistrar);
        formPanel.add(btnActualizar);
        formPanel.add(btnEliminar);

        if (!esAdmin) {
            btnRegistrar.setEnabled(false);
            btnActualizar.setEnabled(false);
            btnEliminar.setEnabled(false);
            String tip = "Solo disponible para administradores";
            btnRegistrar.setToolTipText(tip);
            btnActualizar.setToolTipText(tip);
            btnEliminar.setToolTipText(tip);
        }

        panelCentro.add(formPanel);
        add(panelCentro, BorderLayout.CENTER);
    }

    private void registrar() {
        try {
            Sale s = new Sale(txtSaleDate.getText(),
                    Integer.parseInt(txtEmployeeID.getText()),
                    Integer.parseInt(txtCustomerID.getText()),
                    Double.parseDouble(txtSalesTax.getText()));
            s.setSaleID(Integer.parseInt(txtSaleID.getText()));
            if (saleDAO.registrarSale(s)) { listarSales(); limpiarCampos(); }
            else JOptionPane.showMessageDialog(this,
                    "No se pudo registrar la venta.\nVerifique que el EmployeeID y CustomerID existan.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor verifique los campos numéricos.", "Datos inválidos", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void actualizar() {
        if (idSeleccionado <= 0) return;
        try {
            Sale s = new Sale(txtSaleDate.getText(),
                    Integer.parseInt(txtEmployeeID.getText()),
                    Integer.parseInt(txtCustomerID.getText()),
                    Double.parseDouble(txtSalesTax.getText()));
            s.setSaleID(idSeleccionado);
            if (saleDAO.actualizarSale(s)) { listarSales(); limpiarCampos(); }
            else JOptionPane.showMessageDialog(this, "No se pudo actualizar la venta.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor verifique los campos numéricos.", "Datos inválidos", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void eliminar() {
        if (idSeleccionado <= 0) return;
        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Seguro que desea eliminar esta venta?\n" +
                "Si tiene animales vendidos (SaleAnimal) no se podrá eliminar.",
                "Advertencia", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (saleDAO.eliminarSale(idSeleccionado)) {
                listarSales(); limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this,
                        "No se puede eliminar esta venta.\n" +
                        "Tiene animales registrados en 'Sale Animals'.\n\n" +
                        "Vaya a la sección 'Sale Animals' y elimine\n" +
                        "los registros de esta venta primero.",
                        "Error de integridad referencial",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void listarSales() {
        modeloTabla.setRowCount(0);
        List<Sale> lista = saleDAO.buscarSales(txtBuscar.getText());
        for (Sale s : lista) {
            modeloTabla.addRow(new Object[]{
                s.getSaleID(), s.getSaleDate(), s.getEmployeeID(), s.getCustomerID(), s.getSalesTax()
            });
        }
    }

    private void llenarFormularioDesdeTabla() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            idSeleccionado = (int) modeloTabla.getValueAt(row, 0);
            txtSaleID.setText(modeloTabla.getValueAt(row, 0).toString());
            txtSaleDate.setText(modeloTabla.getValueAt(row, 1).toString());
            txtEmployeeID.setText(modeloTabla.getValueAt(row, 2).toString());
            txtCustomerID.setText(modeloTabla.getValueAt(row, 3).toString());
            txtSalesTax.setText(modeloTabla.getValueAt(row, 4).toString());
        }
    }

    private void limpiarCampos() {
        idSeleccionado = -1;
        txtSaleID.setText(""); txtSaleDate.setText(""); txtEmployeeID.setText("");
        txtCustomerID.setText(""); txtSalesTax.setText("");
    }

    private JLabel crearLabel(String text) {
        JLabel lbl = new JLabel(text); lbl.setForeground(Color.WHITE); return lbl;
    }

    private JButton crearBoton(String text, Color bg, java.awt.event.ActionListener action) {
        JButton btn = new JButton(text);
        btn.setBackground(bg); btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false); btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setMargin(new Insets(5, 15, 5, 15));
        btn.putClientProperty("FlatLaf.style", String.format(
                "background: #%02x%02x%02x; foreground: #ffffff; font: bold 12 \'Segoe UI\'; arc: 16",
                bg.getRed(), bg.getGreen(), bg.getBlue()));
        btn.addActionListener(action);
        return btn;
    }
}