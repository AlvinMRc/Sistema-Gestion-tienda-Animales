package com.pawhouse.system.views;

import com.pawhouse.system.dao.AnimalDAO;
import com.pawhouse.system.models.Animal;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelAnimal extends JPanel {

    private JTextField txtAnimalID, txtName, txtCategory, txtBreed,
            txtDateBorn, txtGender, txtRegistered, txtColor,
            txtListPrice, txtBuscar;

    private JButton btnRegistrar, btnActualizar, btnEliminar;

    private JTable table;
    private DefaultTableModel modeloTabla;
    private AnimalDAO animalDAO;

    private int idSeleccionado = -1;
    private final boolean esAdmin;

    public PanelAnimal(String rol) {
        this.esAdmin = DashboardForm.esRolAdmin(rol);
        animalDAO = new AnimalDAO();
        construirUI();
        listarAnimales();
    }

    /** Constructor sin rol (retrocompatibilidad) */
    public PanelAnimal() {
        this("ADMIN");
    }

    private void construirUI() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(35, 35, 35));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // ================= BUSCADOR =================
        JPanel panelBuscar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBuscar.setBackground(new Color(35, 35, 35));
        panelBuscar.add(crearLabel("Buscar:"));
        txtBuscar = new JTextField(20);
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override public void keyReleased(java.awt.event.KeyEvent evt) { listarAnimales(); }
        });
        panelBuscar.add(txtBuscar);
        add(panelBuscar, BorderLayout.NORTH);

        // ================= CENTRO =================
        JPanel panelCentro = new JPanel(new GridLayout(1, 2, 15, 0));
        panelCentro.setBackground(new Color(35, 35, 35));

        // ================= TABLA =================
        modeloTabla = new DefaultTableModel(
                new Object[]{"ID","Nombre","Categoría","Raza","Nacimiento","Género","Registrado","Color","Precio"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(modeloTabla);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(25);
        table.setSelectionBackground(new Color(244, 162, 97, 80));
        table.getSelectionModel().addListSelectionListener(e -> llenarFormularioDesdeTabla());
        panelCentro.add(new JScrollPane(table));

        // ================= FORMULARIO =================
        JPanel formPanel = new JPanel(new GridLayout(12, 2, 5, 8));
        formPanel.setBackground(new Color(45, 45, 45));
        formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(70, 70, 70)),
                "Datos del Animal", 0, 0,
                new Font("Segoe UI", Font.BOLD, 14), Color.WHITE));

        formPanel.add(crearLabel("Animal ID:"));   txtAnimalID  = new JTextField(); formPanel.add(txtAnimalID);
        formPanel.add(crearLabel("Nombre:"));      txtName      = new JTextField(); formPanel.add(txtName);
        formPanel.add(crearLabel("Categoría:"));   txtCategory  = new JTextField(); formPanel.add(txtCategory);
        formPanel.add(crearLabel("Raza:"));        txtBreed     = new JTextField(); formPanel.add(txtBreed);
        formPanel.add(crearLabel("Fecha Nac.:"));  txtDateBorn  = new JTextField(); formPanel.add(txtDateBorn);
        formPanel.add(crearLabel("Género:"));      txtGender    = new JTextField(); formPanel.add(txtGender);
        formPanel.add(crearLabel("Registrado:"));  txtRegistered= new JTextField(); formPanel.add(txtRegistered);
        formPanel.add(crearLabel("Color:"));       txtColor     = new JTextField(); formPanel.add(txtColor);
        formPanel.add(crearLabel("Precio:"));      txtListPrice = new JTextField(); formPanel.add(txtListPrice);

        formPanel.add(new JLabel(""));
        formPanel.add(new JLabel(""));

        btnRegistrar = crearBoton("Registrar", new Color(46, 204, 113),  e -> registrar());
        btnActualizar= crearBoton("Actualizar", new Color(244, 162, 97), e -> actualizar());
        btnEliminar  = crearBoton("Eliminar",   new Color(231, 76, 60),  e -> eliminar());

        formPanel.add(btnRegistrar);
        formPanel.add(btnActualizar);
        formPanel.add(btnEliminar);

        // Aplicar restricciones de rol
        if (!esAdmin) {
            btnRegistrar.setEnabled(false);
            btnActualizar.setEnabled(false);
            btnEliminar.setEnabled(false);
            btnRegistrar.setToolTipText("Solo disponible para administradores");
            btnActualizar.setToolTipText("Solo disponible para administradores");
            btnEliminar.setToolTipText("Solo disponible para administradores");
        }

        panelCentro.add(formPanel);
        add(panelCentro, BorderLayout.CENTER);
    }

    // ================= REGISTRAR =================
    private void registrar() {
        try {
            Animal a = new Animal(
                    txtName.getText(), txtCategory.getText(), txtBreed.getText(),
                    txtDateBorn.getText(), txtGender.getText(), txtRegistered.getText(),
                    txtColor.getText(), Double.parseDouble(txtListPrice.getText()));
            a.setAnimalID(Integer.parseInt(txtAnimalID.getText()));
            if (animalDAO.registrarAnimal(a)) { listarAnimales(); limpiarCampos(); }
            else JOptionPane.showMessageDialog(this, "No se pudo registrar el animal.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor verifique los campos numéricos.", "Datos inválidos", JOptionPane.WARNING_MESSAGE);
        }
    }

    // ================= ACTUALIZAR =================
    private void actualizar() {
        if (idSeleccionado <= 0) return;
        try {
            Animal a = new Animal(
                    txtName.getText(), txtCategory.getText(), txtBreed.getText(),
                    txtDateBorn.getText(), txtGender.getText(), txtRegistered.getText(),
                    txtColor.getText(), Double.parseDouble(txtListPrice.getText()));
            a.setAnimalID(idSeleccionado);
            if (animalDAO.actualizarAnimal(a)) { listarAnimales(); limpiarCampos(); }
            else JOptionPane.showMessageDialog(this, "No se pudo actualizar el animal.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor verifique los campos numéricos.", "Datos inválidos", JOptionPane.WARNING_MESSAGE);
        }
    }

    // ================= ELIMINAR =================
    private void eliminar() {
        if (idSeleccionado <= 0) return;
        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Seguro que desea eliminar este animal?\n" +
                "Si tiene ventas u órdenes relacionadas no se podrá eliminar.",
                "Advertencia", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (animalDAO.eliminarAnimal(idSeleccionado)) {
                listarAnimales(); limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this,
                        "No se puede eliminar este animal.\n" +
                        "Tiene registros relacionados en otras tablas\n" +
                        "(ventas u órdenes de compra).\n\n" +
                        "Elimine primero los registros relacionados.",
                        "Error de integridad referencial",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // ================= LISTAR =================
    private void listarAnimales() {
        modeloTabla.setRowCount(0);
        List<Animal> lista = animalDAO.buscarAnimales(txtBuscar.getText());
        for (Animal a : lista) {
            modeloTabla.addRow(new Object[]{
                a.getAnimalID(), a.getName(), a.getCategory(), a.getBreed(),
                a.getDateBorn(), a.getGender(), a.getRegistered(), a.getColor(), a.getListPrice()
            });
        }
    }

    // ================= LLENAR FORM =================
    private void llenarFormularioDesdeTabla() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            idSeleccionado = (int) modeloTabla.getValueAt(row, 0);
            txtAnimalID.setText(modeloTabla.getValueAt(row, 0).toString());
            txtName.setText(modeloTabla.getValueAt(row, 1).toString());
            txtCategory.setText(modeloTabla.getValueAt(row, 2).toString());
            txtBreed.setText(modeloTabla.getValueAt(row, 3).toString());
            txtDateBorn.setText(modeloTabla.getValueAt(row, 4).toString());
            txtGender.setText(modeloTabla.getValueAt(row, 5).toString());
            txtRegistered.setText(modeloTabla.getValueAt(row, 6).toString());
            txtColor.setText(modeloTabla.getValueAt(row, 7).toString());
            txtListPrice.setText(modeloTabla.getValueAt(row, 8).toString());
        }
    }

    // ================= LIMPIAR =================
    private void limpiarCampos() {
        idSeleccionado = -1;
        txtAnimalID.setText(""); txtName.setText(""); txtCategory.setText("");
        txtBreed.setText(""); txtDateBorn.setText(""); txtGender.setText("");
        txtRegistered.setText(""); txtColor.setText(""); txtListPrice.setText("");
    }

    private JLabel crearLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setForeground(Color.WHITE);
        return lbl;
    }

    private JButton crearBoton(String text, Color bg, java.awt.event.ActionListener action) {
        JButton btn = new JButton(text);
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setMargin(new Insets(5, 15, 5, 15));
        // FlatLaf requiere putClientProperty para respetar colores personalizados
        btn.putClientProperty("FlatLaf.style", String.format(
                "background: #%02x%02x%02x; foreground: #ffffff; font: bold 12 \'Segoe UI\'; arc: 16",
                bg.getRed(), bg.getGreen(), bg.getBlue()));
        btn.addActionListener(action);
        return btn;
    }
}