package com.pawhouse.system;

import com.formdev.flatlaf.FlatDarkLaf;
import com.pawhouse.system.views.LoginForm;
import javax.swing.*;

public class App {
    public static void main(String args[]) {
        // Configurar el diseño FlatLaf Oscuro
        try {
            UIManager.setLookAndFeel(new FlatDarkLaf());
        } catch (UnsupportedLookAndFeelException ex) {
            System.err.println("Falló la inicialización del tema FlatLaf");
        }
        
        // Iniciar interfaz en el hilo de eventos de Swing
        SwingUtilities.invokeLater(() -> {
            new LoginForm().setVisible(true);
        });
    }
}