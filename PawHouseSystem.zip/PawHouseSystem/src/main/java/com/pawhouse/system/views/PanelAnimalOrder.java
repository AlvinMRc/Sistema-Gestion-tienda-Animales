package com.pawhouse.system.views;

import com.pawhouse.system.dao.AnimalOrderDAO;
import com.pawhouse.system.models.AnimalOrder;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelAnimalOrder extends JPanel {

    private JTextField txtOrderID, txtOrderDate, txtReceiveDate,
            txtSupplierID, txtShippingCost, txtEmployeeID, txtBuscar;

    private JButton btnRegistrar, btnActualizar, btnEliminar;
    private JTable table;
    private DefaultTableModel modeloTabla;
    private AnimalOrderDAO orderDAO;
    private int idSeleccionado = -1;
    private final boolean esAdmin;

    public PanelAnimalOrder(String rol) {
        this.esAdmin = DashboardForm.esRolAdmin(rol);
        orderDAO = new AnimalOrderDAO();
        construirUI();
        listarOrdenes();
    }

    public PanelAnimalOrder() { this("ADMIN"); }

    private void construirUI() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(35, 35, 35));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // ================= BUSCADOR =================
        JPanel panelBuscar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBuscar.setBackground(new Color(35, 35, 35));
        panelBuscar.add(crearLabel("Buscar:"));
        txtBuscar = new JTextField(20);
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override public void keyReleased(java.awt.event.KeyEvent evt) { listarOrdenes(); }
        });
        panelBuscar.add(txtBuscar);
        add(panelBuscar, BorderLayout.NORTH);

        // ================= PANEL CENTRAL =================
        JPanel panelCentro = new JPanel(new GridLayout(1, 2, 15, 0));
        panelCentro.setBackground(new Color(35, 35, 35));

        // ================= TABLA =================
        modeloTabla = new DefaultTableModel(
                new Object[]{"OrderID","OrderDate","ReceiveDate","SupplierID","ShippingCost","EmployeeID"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(modeloTabla);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(25);
        table.setSelectionBackground(new Color(244, 162, 97, 80));
        table.getSelectionModel().addListSelectionListener(e -> llenarFormularioDesdeTabla());
        panelCentro.add(new JScrollPane(table));

        // ================= FORMULARIO =================
        JPanel formPanel = new JPanel(new GridLayout(10, 2, 5, 8));
        formPanel.setBackground(new Color(45, 45, 45));
        formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(70, 70, 70)),
                "Datos de la Orden", 0, 0,
                new Font("Segoe UI", Font.BOLD, 14), Color.WHITE));

        formPanel.add(crearLabel("Order ID:"));      txtOrderID      = new JTextField(); formPanel.add(txtOrderID);
        formPanel.add(crearLabel("Order Date:"));    txtOrderDate    = new JTextField(); formPanel.add(txtOrderDate);
        formPanel.add(crearLabel("Receive Date:"));  txtReceiveDate  = new JTextField(); formPanel.add(txtReceiveDate);
        formPanel.add(crearLabel("Supplier ID:"));   txtSupplierID   = new JTextField(); formPanel.add(txtSupplierID);
        formPanel.add(crearLabel("Shipping Cost:")); txtShippingCost = new JTextField(); formPanel.add(txtShippingCost);
        formPanel.add(crearLabel("Employee ID:"));   txtEmployeeID   = new JTextField(); formPanel.add(txtEmployeeID);

        formPanel.add(new JLabel("")); formPanel.add(new JLabel(""));

        btnRegistrar  = crearBoton("Registrar",  new Color(46, 204, 113),  e -> registrar());
        btnActualizar = crearBoton("Actualizar",  new Color(244, 162, 97), e -> actualizar());
        btnEliminar   = crearBoton("Eliminar",    new Color(231, 76, 60),  e -> eliminar());

        formPanel.add(btnRegistrar);
        formPanel.add(btnActualizar);
        formPanel.add(btnEliminar);

        if (!esAdmin) {
            btnRegistrar.setEnabled(false);
            btnActualizar.setEnabled(false);
            btnEliminar.setEnabled(false);
            String tip = "Solo disponible para administradores";
            btnRegistrar.setToolTipText(tip);
            btnActualizar.setToolTipText(tip);
            btnEliminar.setToolTipText(tip);
        }

        panelCentro.add(formPanel);
        add(panelCentro, BorderLayout.CENTER);
    }

    private void registrar() {
        try {
            AnimalOrder o = new AnimalOrder(
                    txtOrderDate.getText(), txtReceiveDate.getText(),
                    Integer.parseInt(txtSupplierID.getText()),
                    Double.parseDouble(txtShippingCost.getText()),
                    Integer.parseInt(txtEmployeeID.getText()));
            o.setOrderID(Integer.parseInt(txtOrderID.getText()));
            if (orderDAO.registrarOrden(o)) { listarOrdenes(); limpiarCampos(); }
            else JOptionPane.showMessageDialog(this, "No se pudo registrar la orden.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor verifique los campos numéricos.", "Datos inválidos", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void actualizar() {
        if (idSeleccionado <= 0) return;
        try {
            AnimalOrder o = new AnimalOrder(
                    txtOrderDate.getText(), txtReceiveDate.getText(),
                    Integer.parseInt(txtSupplierID.getText()),
                    Double.parseDouble(txtShippingCost.getText()),
                    Integer.parseInt(txtEmployeeID.getText()));
            o.setOrderID(idSeleccionado);
            if (orderDAO.actualizarOrden(o)) { listarOrdenes(); limpiarCampos(); }
            else JOptionPane.showMessageDialog(this, "No se pudo actualizar la orden.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor verifique los campos numéricos.", "Datos inválidos", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void eliminar() {
        if (idSeleccionado <= 0) return;
        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Seguro que desea eliminar esta orden?\n" +
                "Elimine primero los 'Order Items' relacionados.",
                "Advertencia", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (orderDAO.eliminarOrden(idSeleccionado)) {
                listarOrdenes(); limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this,
                        "No se puede eliminar esta orden.\n" +
                        "Tiene ítems (AnimalOrderItems) asociados.\n\n" +
                        "Vaya a la sección 'Order Items' y elimine\n" +
                        "los ítems de esta orden primero.",
                        "Error de integridad referencial",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void listarOrdenes() {
        modeloTabla.setRowCount(0);
        List<AnimalOrder> lista = orderDAO.buscarOrdenes(txtBuscar.getText());
        for (AnimalOrder o : lista) {
            modeloTabla.addRow(new Object[]{
                o.getOrderID(), o.getOrderDate(), o.getReceiveDate(),
                o.getSupplierID(), o.getShippingCost(), o.getEmployeeID()
            });
        }
    }

    private void llenarFormularioDesdeTabla() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            idSeleccionado = (int) modeloTabla.getValueAt(row, 0);
            txtOrderID.setText(modeloTabla.getValueAt(row, 0).toString());
            txtOrderDate.setText(modeloTabla.getValueAt(row, 1).toString());
            txtReceiveDate.setText(modeloTabla.getValueAt(row, 2).toString());
            txtSupplierID.setText(modeloTabla.getValueAt(row, 3).toString());
            txtShippingCost.setText(modeloTabla.getValueAt(row, 4).toString());
            txtEmployeeID.setText(modeloTabla.getValueAt(row, 5).toString());
        }
    }

    private void limpiarCampos() {
        idSeleccionado = -1;
        txtOrderID.setText(""); txtOrderDate.setText(""); txtReceiveDate.setText("");
        txtSupplierID.setText(""); txtShippingCost.setText(""); txtEmployeeID.setText("");
    }

    private JLabel crearLabel(String text) {
        JLabel lbl = new JLabel(text); lbl.setForeground(Color.WHITE); return lbl;
    }

    private JButton crearBoton(String text, Color bg, java.awt.event.ActionListener action) {
        JButton btn = new JButton(text);
        btn.setBackground(bg); btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false); btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setMargin(new Insets(5, 15, 5, 15));
        btn.putClientProperty("FlatLaf.style", String.format(
                "background: #%02x%02x%02x; foreground: #ffffff; font: bold 12 \'Segoe UI\'; arc: 16",
                bg.getRed(), bg.getGreen(), bg.getBlue()));
        btn.addActionListener(action);
        return btn;
    }
}