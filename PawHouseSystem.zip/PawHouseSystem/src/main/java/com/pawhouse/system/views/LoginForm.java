package com.pawhouse.system.views;

import com.pawhouse.system.config.DatabaseConnection;
import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class LoginForm extends JFrame {
    
    private JTextField txtUser;
    private JPasswordField txtPass;
    private JButton btnLogin;

    public LoginForm() {
        initComponents();
        setLocationRelativeTo(null); // Centrar pantalla
    }

    private void initComponents() {
        setTitle("Paw House System - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setResizable(false);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel lblTitle = new JLabel("PAW HOUSE", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(new Color(244, 162, 97)); // Color arena/mascota
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(lblTitle, gbc);

        // Usuario
        gbc.gridwidth = 1; gbc.gridy = 1; gbc.gridx = 0;
        add(new JLabel("Usuario:"), gbc);
        gbc.gridx = 1;
        txtUser = new JTextField(15);
        add(txtUser, gbc);

        // Contraseña
        gbc.gridy = 2; gbc.gridx = 0;
        add(new JLabel("Contraseña:"), gbc);
        gbc.gridx = 1;
        txtPass = new JPasswordField(15);
        add(txtPass, gbc);

        // Botón
        btnLogin = new JButton("Ingresar");
        btnLogin.setBackground(new Color(42, 157, 143)); // Verde Veterinary
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLogin.addActionListener(e -> validarLogin());
        gbc.gridy = 3; gbc.gridx = 0; gbc.gridwidth = 2;
        add(btnLogin, gbc);
    }

    private void validarLogin() {
        String user = txtUser.getText().trim();
        String pass = new String(txtPass.getPassword());

        if (user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Complete todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sql = "SELECT * FROM usuarios WHERE username = ? AND password = ? AND estado = TRUE";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            
            pst.setString(1, user);
            pst.setString(2, pass);
            
            ResultSet rs = pst.executeQuery();
 if (rs.next()) {
    String rol = rs.getString("rol");
    // ABRIMOS EL DASHBOARD Y CERRAMOS EL LOGIN
    new DashboardForm(rol).setVisible(true);
    this.dispose(); 

            } else {
                JOptionPane.showMessageDialog(this, "Credenciales incorrectas o usuario inactivo", "Acceso denegado", JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error de base de datos: " + e.getMessage(), "Error Crítico", JOptionPane.ERROR_MESSAGE);
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(this, "No se pudo conectar a la base de datos. ¿Está encendido Laragon?", "Error de Conexión", JOptionPane.ERROR_MESSAGE);
        }
    }
}