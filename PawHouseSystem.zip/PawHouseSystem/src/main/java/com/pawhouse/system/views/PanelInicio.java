package com.pawhouse.system.views;

import javax.swing.*;
import java.awt.*;

public class PanelInicio extends JPanel {

    public PanelInicio() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(45, 45, 45));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // --- ENCABEZADO ---
        JLabel lblBienvenida = new JLabel("Bienvenido a Paw House System");
        lblBienvenida.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblBienvenida.setForeground(new Color(244, 162, 97));
        add(lblBienvenida, BorderLayout.NORTH);

        // --- PANEL DE TARJETAS ESTADÍSTICAS ---
        JPanel panelTarjetas = new JPanel(new GridLayout(1, 4, 15, 15));
        panelTarjetas.setBackground(new Color(45, 45, 45));

        panelTarjetas.add(crearTarjeta("Clientes Activos", "0", new Color(52, 152, 219)));
        panelTarjetas.add(crearTarjeta("Ventas Hoy", "0", new Color(46, 204, 113)));
        panelTarjetas.add(crearTarjeta("Mascotas registradas", "0", new Color(244, 162, 97)));
        panelTarjetas.add(crearTarjeta("Citas Pendientes", "0", new Color(231, 76, 60)));

        add(panelTarjetas, BorderLayout.CENTER);

        // --- CONTENIDO INFERIOR (Placeholder para gráficos futuros) ---
        JPanel panelInferior = new JPanel(new GridLayout(1, 2, 15, 15));
        panelInferior.setBackground(new Color(45, 45, 45));
        
        JPanel cardGrafico = crearCard("Gráfico de Ventas", "");
        JPanel cardRecientes = crearCard("Últimas Facturas", "");
        
        panelInferior.add(cardGrafico);
        panelInferior.add(cardRecientes);
        
        add(panelInferior, BorderLayout.SOUTH);
    }

    // Método para crear las tarjetas de estadísticas superiores
    private JPanel crearTarjeta(String titulo, String valor, Color colorFondo) {
        JPanel tarjeta = new JPanel();
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBackground(colorFondo);
        tarjeta.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblValor = new JLabel(valor);
        lblValor.setFont(new Font("Segoe UI", Font.BOLD, 32));
        lblValor.setForeground(Color.WHITE);
        lblValor.setAlignmentX(Component.LEFT_ALIGNMENT);

        tarjeta.add(lblTitulo);
        tarjeta.add(Box.createRigidArea(new Dimension(0, 10)));
        tarjeta.add(lblValor);

        return tarjeta;
    }

    // Método para crear las cards inferiores
    private JPanel crearCard(String titulo, String contenido) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(new Color(55, 55, 55));
        card.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(70, 70, 70)), 
            titulo, 0, 0, new Font("Segoe UI", Font.BOLD, 14), Color.WHITE));
        
        JLabel lblContenido = new JLabel(contenido, SwingConstants.CENTER);
        lblContenido.setForeground(new Color(180, 180, 180));
        card.add(lblContenido, BorderLayout.CENTER);
        
        return card;
    }
}